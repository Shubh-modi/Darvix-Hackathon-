import argparse, json, sys
from backend.generator import generate_markdown_report

def main():
    p = argparse.ArgumentParser(description="Mission 1: Empathetic Code Reviewer (CLI)")
    p.add_argument("--json", type=str, help="Path to input JSON file with 'code_snippet' and 'review_comments'")
    args = p.parse_args()

    if not args.json:
        print("Provide --json <path> to an input file.", file=sys.stderr)
        sys.exit(1)

    with open(args.json, "r", encoding="utf-8") as f:
        payload = json.load(f)

    md = generate_markdown_report(payload)
    print(md)

if __name__ == "__main__":
    main()
