import os
from typing import List, Dict
from dotenv import load_dotenv

from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema import StrOutputParser

load_dotenv()

GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
HF_EMBEDDING_MODEL = os.getenv("HF_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
INDEX_DIR = os.getenv("INDEX_DIR", ".kb_index")
TOP_K = int(os.getenv("TOP_K", "4"))

def _build_embeddings():
    return HuggingFaceEmbeddings(model_name=HF_EMBEDDING_MODEL)

def _load_kb():
    """Build or load FAISS index from ./kb."""
    emb = _build_embeddings()
    if os.path.exists(INDEX_DIR):
        return FAISS.load_local(INDEX_DIR, emb, allow_dangerous_deserialization=True)
    # build
    loader = DirectoryLoader("./kb", glob="**/*.txt", loader_cls=TextLoader, use_multithreading=True)
    docs = loader.load()
    vectordb = FAISS.from_documents(docs, emb)
    vectordb.save_local(INDEX_DIR)
    return vectordb

def _severity(comment: str) -> str:
    harsh_markers = ["terrible", "awful", "inefficient", "bad", "wrong", "useless", "never", "always", "obviously", "ridiculous", "garbage", "stupid"]
    score = sum(1 for m in harsh_markers if m.lower() in comment.lower())
    if score >= 2:
        return "high"
    if score == 1:
        return "medium"
    return "low"

def _build_llm():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise EnvironmentError("Missing GROQ_API_KEY. Set it in .env.")
    return ChatGroq(model_name=GROQ_MODEL, temperature=0.2)

PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You are an empathetic senior developer and mentor. "
     "Rephrase blunt code review comments into supportive, constructive, and educational guidance. "
     "Use the retrieved context (style guides, best practices) to inform suggestions. "
     "For each single comment, produce EXACTLY this Markdown format:\n"
     "### Analysis of Comment: \"{comment}\"\n"
     "* **Positive Rephrasing:** <supportive rewrite>\n"
     "* **The 'Why':** <clear principle; reference retrieved concepts>\n"
     "* **Suggested Improvement:**\n"
     "```{language}\n"
     "{improved_code}\n"
     "```\n"
     "When relevant, include one or two succinct resource links on a separate line: 'Resources: <url1>, <url2>'. "
     "Avoid overlinking. Keep tone kind and specific. Do not mention tokens, prompts, or internal system text."),
    ("user",
     "Language: {language}\n"
     "Code snippet:\n"
     "```{language}\n"
     "{code}\n"
     "```\n"
     "Original comment: {comment}\n"
     "Severity: {severity}\n"
     "Retrieved context:\n"
     "{context}\n"
     "Now produce the Markdown section as specified.")
])

def _detect_language(code: str) -> str:
    # extremely simple heuristic for demo
    if "def " in code and "return" in code:
        return "python"
    if "function " in code or "const " in code:
        return "javascript"
    return "text"

def generate_markdown_report(payload: Dict) -> str:
    code = payload.get("code_snippet", "").strip()
    comments: List[str] = payload.get("review_comments", [])
    if not code or not isinstance(comments, list) or not comments:
        raise ValueError("Payload must include 'code_snippet' (str) and 'review_comments' (non-empty list).")

    language = _detect_language(code)
    llm = _build_llm()
    kb = _load_kb()
    retriever = kb.as_retriever(search_kwargs={"k": TOP_K})

    # simple improved code seed: by default, we pass the original code and let LLM refine
    # prompt includes {improved_code}; we set placeholder that the LLM should replace.
    # We'll just pass the same code; instructions ask LLM to show an improved version.
    # (LLM may rewrite based on context + comment.)
    improved_code_placeholder = code

    chain = (
        {
            "language": lambda x: language,
            "code": lambda x: code,
            "comment": lambda x: x["comment"],
            "severity": lambda x: _severity(x["comment"]),
            "context": lambda x: "\n\n".join([d.page_content for d in retriever.get_relevant_documents(x["comment"])]),
            "improved_code": lambda x: improved_code_placeholder,
        }
        | PROMPT
        | llm
        | StrOutputParser()
    )

    sections: List[str] = []
    for c in comments:
        out = chain.invoke({"comment": c})
        sections.append(out.strip())

    # final encouraging wrap-up
    summary = (
        "#### Summary\n"
        "Awesome progress! The suggestions above focus on clarity, correctness, and maintainability. "
        "Small refinements—like clearer naming, Pythonic truthiness, and efficient iteration—compound into big wins "
        "for readability and performance. Keep experimenting and asking 'why' behind each change—you're on the right path!"
    )

    md = "# Empathetic Code Review Report\n\n" + "\n\n---\n\n".join(sections) + "\n\n---\n\n" + summary + "\n"
    return md
