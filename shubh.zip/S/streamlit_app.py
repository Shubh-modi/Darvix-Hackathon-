import os, json, textwrap, streamlit as st
from backend.generator import generate_markdown_report

st.set_page_config(page_title="Empathetic Code Reviewer", page_icon="💬", layout="wide")

st.title("💬 The Empathetic Code Reviewer")
st.caption("Transforming Critical Feedback into Constructive Growth — Groq Llama 3 + LangChain + HF Embeddings")

with st.sidebar:
    st.subheader("Model Settings")
    model = st.text_input("Groq Model", value=os.getenv("GROQ_MODEL", "llama-3.1-8b-instant"))
    st.caption("Set GROQ_MODEL in .env or here. Requires GROQ_API_KEY in environment.")

st.write("### Input")
tab1, tab2 = st.tabs(["Form", "Raw JSON"])

with tab1:
    code = st.text_area("Code Snippet", height=240, placeholder="Paste your code here...")
    comments_raw = st.text_area("Review Comments (one per line)", height=160, placeholder="e.g.\nThis is inefficient. Don't loop twice conceptually.\nVariable 'u' is a bad name.\nBoolean comparison '== True' is redundant.")
    submit_form = st.button("Generate Report", type="primary")

with tab2:
    example = {
        "code_snippet": "def get_active_users(users):\n    results = []\n    for u in users:\n        if u.is_active == True and u.profile_complete == True:\n            results.append(u)\n    return results",
        "review_comments": [
            "This is inefficient. Don't loop twice conceptually.",
            "Variable 'u' is a bad name.",
            "Boolean comparison '== True' is redundant."
        ]
    }
    raw_json = st.text_area("JSON Input", height=300, value=json.dumps(example, indent=2))
    submit_json = st.button("Generate from JSON", type="secondary")

payload = None
if submit_form and code.strip():
    comments = [c.strip() for c in comments_raw.splitlines() if c.strip()]
    payload = {"code_snippet": code, "review_comments": comments}
elif submit_json:
    try:
        payload = json.loads(raw_json)
    except Exception as e:
        st.error(f"Invalid JSON: {e}")

if payload:
    try:
        md = generate_markdown_report(payload)
        st.success("Report generated!")
        st.download_button("Download Markdown", data=md, file_name="empathetic_review_report.md")
        st.markdown(md)
    except Exception as e:
        st.error(str(e))
        st.stop()

st.markdown("---")
st.write("**Tips**: Add more best-practice notes into the `kb/` folder to enrich the assistant's guidance.")
